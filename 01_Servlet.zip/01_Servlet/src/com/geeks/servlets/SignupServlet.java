package com.geeks.servlets;
import com.geeks.connection.*;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.geeks.connection.DBConnection;

import java.sql.*;
/**
 * Servlet implementation class SignupServlet
 */
@WebServlet("/SignupServlet")
public class SignupServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con = DBConnection.makeConnection();
    /**
     * Default constructor. 
     */
    public SignupServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String s="<body>";
		s+="<h1>SignUp Page</h1>";
		s+="<br>";
		s+="<form action='SignupServlet' method = 'post'>";
		s+="Username<input type = 'text' name='username'><br>";		
		s+="Password<input type = 'password' name = 'password'><br>";
		s+="<input type='submit' name='signup' value='SignUp'>";
		s+="<input type='submit' name='login' value='Login'>";
		s+="</form>";
		s+="</body>";
		out.print(s);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
		doGet(request, response);
		String username = request.getParameter("username").toString();
		String password = request.getParameter("password").toString();
		PrintWriter out = response.getWriter();
		if(request.getParameter("login")!=null){
		try {
			PreparedStatement pst = con.prepareStatement("Select * from login where username=? and password=?");
			pst.setString(1, username);
			pst.setString(2, password);
			ResultSet rs = pst.executeQuery();
			if(rs.next()){
				out.print("<h1>Login Success</h1>");
		//	RequestDispatcher rd=request.getRequestDispatcher("/HomeServlet");
		//	rd.forward(request, response);
			response.sendRedirect("HomeServlet?username="+username+"");	
			}else{
				out.print("<h1>Login Error</h1>");
			}
		} catch (SQLException e){}
		}else{
			try {
				PreparedStatement pst = con.prepareStatement("Insert into login values(?,?)");
				pst.setString(1, username);
				pst.setString(2, password);
				int check = pst.executeUpdate();
				if(check!=0){
					out.print("<h1>Your are Sign Up</h1>");
				}else{
					out.print("<h1>Sign Up Error</h1>");
				}
			} catch (SQLException e){}
		}
	}

}
 