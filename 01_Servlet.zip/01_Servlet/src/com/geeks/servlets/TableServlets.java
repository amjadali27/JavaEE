package com.geeks.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TableServlets
 */
@WebServlet("/TableServlets")
public class TableServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public TableServlets() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletConfig config=getServletConfig();
		PrintWriter out = response.getWriter();
		String filePath=config.getInitParameter("filePath");
		out.print("File Path is: "+filePath);
	    
	    doPost(request, response);
	
	}

	
	
	
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		out.print("<html>");
		out.print("<body>");
		out.print("<h1>Table Generate</h1><br>");
		out.print("<form action='TableServlets' method = 'get'>");
		out.print("Table<input type='number' name = 'number'>");
		out.print("<br/>");
		out.print("<input type='submit' value='Generate'/>");
		out.print("</form>");
		
		if(request.getParameter("number")!=null){
				int number = Integer.parseInt(request.getParameter("number").toString());
		
		String table = "";
		for(int i=1;i<11;i++){
			table+=i+" * "+number+" = "+(i*number)+"<br />";
		}
		out.print(table);
		}
	
	}

}
