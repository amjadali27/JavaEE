package com.geeks.connection;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.JOptionPane;

public class DBConnection {
	private DBConnection(){}
    public static Connection con=null;
    public static Connection makeConnection(){
        try{
            if(con==null){
                con=DriverManager.getConnection("jdbc:mysql://localhost:3306/practice_db","root","amjadalidahri");
            }
        }catch(Exception e){}
        return con;
    }
	
}
